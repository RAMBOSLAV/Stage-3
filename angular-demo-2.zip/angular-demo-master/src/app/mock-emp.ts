import { Employee } from "./employee.model";


export const EMPLOYEES: Employee[] = [
    { id: 11, firstName: 'Rambo' },
    { id: 12, firstName: 'Zoro' },
    { id: 13, firstName: 'Itachi' },
    
  ];