// import { DatePipe } from "@angular/common";

export interface Skill{
    id: number,
    name: string
}