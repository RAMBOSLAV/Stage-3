import { DatePipe } from "@angular/common";

export interface Employee{
   
    firstName: string,
    id: number;
    
    
    
}

    